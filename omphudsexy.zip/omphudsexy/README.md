#omphud-redux

classic omphud, updated to 2020 with all sorts of new goodies thrown in

Version: 1.2H
Released: May 17th, 2020

visit hudlayout.res to install custom crosshairs

